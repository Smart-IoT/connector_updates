#!/bin/bash

## INFO ##
## $0 = Filename dieses Scripts
## $1 = Option 1 -> case
## $2 = Option 2 -> Parameter für den case
## Beispiel für Verwendung der eingelesenen Variablen: echo $UCID
## Beispiel für das Ändern der Variable im File: sed -i 's/UCID.*$/UCID="'$2'"/' .app/settings.conf
## ACHTUNG, es werden immer ALLE Zeichenfolgen ersetzt, Variablenname müssen also eindeutig sein, auch in Teilen

## Alle Variablen einlesen
## Pfad ist relativ zum Arbeitsverzeichnis
###### Eventuell Auskommentieren
source .app/app.conf
source .ucid/ucid.conf

case $1 in

### Parameter in app.conf schreiben / überschreiben ###  
-writeAPPconfig)
  para=$2
  wert=$3
  ## sed -i 's/CCID.*$/CCID="'$2'"/' .app/app.conf
  sed -i 's/'$para'.*/'$para'="'$wert'"/' .app/app.conf
  echo Parameter ${para} = ${wert} written to app.conf!
  ;;
  
### Parameter in setings.conf schreiben / überschreiben ###  
-wset)
  para=$2
  wert=$3
  sed -i 's/'$para'.*/'$para','$wert'/' .app/settings.conf
  echo ${para}","${wert}" written to settings.conf!"
  ;;

-uc)
## Register connenctor (Register User Connector ID UCID)
## Die UCID (User Connector ID) wird in eine eigenes File ucid.conf geschrieben.
## Dises File wird bei Updates nicht überschrieben
uuid=$2
  if [[ ${uuid//-/} =~ ^[[:xdigit:]]{32}$ ]]; then
      echo "UUID Format correct!"
	
	  ## lesen der aktuellen ID
      echo "Current UCID: "$UCID
      sleep 1

      #$1 wird von eingabe übernommen
      echo "--> New UCID: "$2
	  
      # Ersetze vorhandene UCID durch neue UCID in File ucid.conf
	  sed -i 's/UCID.*$/UCID="'$2'"/' .ucid/ucid.conf

      # Ersetze vorhandene UCID durch neue UCID in File .node-red/flows.json
      echo "Set new UCID: "$2
	  echo ""
      sed -i -- 's/'$UCID'/'$2'/g' .node-red/flows.json
      sleep 1

      # Node-Red neu starten
      echo "All done, restart APP ..."
      systemctl restart node-red
  else
      echo "UCID not allowed"
  fi
  ## Message="Register connenctor complete"
  ;;

-cc)
uuid=$2
  if [[ ${uuid//-/} =~ ^[[:xdigit:]]{32}$ ]]; then
      echo "UUID Format correct!"
	
	  ## lesen der aktuellen ID
      echo "Current CCID: "$CCID
      sleep 1

      #$1 wird von eingabe übernommen
      echo "--> New CCID: "$2
	  
      # Ersetze aktuelle CCID durch neue CCID in File .variables
	  sed -i 's/CCID.*$/CCID="'$2'"/' .app/app.conf
	  echo "Done."
  else
      echo "CCID not allowed"
  fi
  ;;

-o)
  ## Dieses Script erzeugt eine original flow.json mit default MQTT-ID (UCID)
  echo "> Current UCID: "$UCID
  sleep 1
  
  ## Copy the current flows.json-file
  echo ">> Copy current flows.json to flows.json.original" 
  sudo cp .node-red/flows.json .app/flows.json.original
  sleep 1
  echo ">>> File 'flows.json.original' created."
  sleep 1
  
  ## Change the User Connector ID (UCID) to Default User ID (DUID)
  echo ">>>> Change '$UCID' to '$DUID' in File flows.json.original"
  sudo sed -i 's/'$UCID'/'$DUID'/g' .app/flows.json.original
  sleep 1
  
  echo "Done."
  ;;

### Delete UCID ###  
-d)
  echo "> Current UCID: "$UCID
  sleep 1
  
  ## Change the UCID to default
  echo ">> Change UCID to '$DUID' in flows.json"
  sudo sed -i 's/'$UCID'/'$DUID'/g' .node-red/flows.json
  sleep 1
  
  ## Ersetze UCID und CCID durch die Default DUID im File ucid.conf bzw. app.conf
  ## Die CCID muss ebenfalls gelöscht werden, damit die Daten vom MQTT Parser nicht mehr akzeptiert werden.
  ## Im Falle einer Neu-Registrierung einer UCID wird die CCID via Internet-Loop neu geladen.
  echo ">>> Change UCID ans CCID to Default in File app.conf"
  sed -i 's/UCID.*$/UCID="'$DUID'"/' .ucid/ucid.conf
  sleep 1
  sed -i 's/CCID.*$/CCID="'$DUID'"/' .app/app.conf
  sleep 1

  # Restart Node-Red
  echo ">>>> Restart APP, this needs a few seconds, don't worry!"
  sudo systemctl restart node-red
  ;;
  
### Version lesen ###  
-v)
  echo $VERS" | "$DATI
  ;;

### Version schreiben ###  
-setv)
  option=$2
  ## Zeitstempel erzeugen
  DT=`date '+%Y-%m-%d-%H-%M-%S'`
  sed -i 's/DATI.*$/DATI="'${DT}'"/' .app/app.conf
  sed -i 's/VERS.*$/VERS="'$option'"/' .app/app.conf
  echo "> Version written to app.conf!"
  ;;

### WIFI ###
-wifi)
  option=$2
  SSID=$3
  PWD=$4
  case $option in
    status)
      echo $WIFI
      ;;
    1)
      nmcli r wifi on
	  sed -i 's/WIFI.*$/WIFI="'$option'"/' .app/app.conf
      ;;	 
    0)
      nmcli r wifi off
	  sed -i 's/WIFI.*$/WIFI="'$option'"/' .app/app.conf
	  ;;
	connect)
	  sed -i 's/SET_APMODE*$/SET_APMODE,0/' .app/settings.conf
	  nmcli con down directWIFI
	  echo Shut down directWIFI
	  sleep 5
	##sudo nmcli dev wifi connect <SSID> password <PWD> ifname wlan0
      sudo nmcli dev wifi connect ${SSID} password ${PWD} ifname wlan0
	  echo Connect to ${SSID}
	  ;;
	addconnection)
	  nmcli con add type wifi ifname wlan0 con-name "${SSID}" autoconnect no ssid "${SSID}" 802-11-wireless.mode ap 802-11-wireless.band bg ipv4.method shared wifi-sec.key-mgmt wpa-psk wifi-sec.psk "${PWD}"
	  ;;
    *)
    Message="Type '$0 -help' for more information"
    ;;
  esac	
  ;;
  
### directWIFI ###
-apmode)
  option=$2
  case $option in
    1)
      sed -i 's/SET_APMODE*$/SET_APMODE,'$option'/' .app/settings.conf
	  sudo nmcli con up directWIFI
	  echo 1
      ;;	 
    0)
	  sed -i 's/SET_APMODE*$/SET_APMODE,'$option'/' .app/settings.conf
	  sudo nmcli con down directWIFI
	  echo 0
	  ;;
    *)
    Message="Type '$0 -help' for more information"
    ;;
  esac	
  ;;

### DATALOGGER ###
-logger)
  option=$2
  case $option in
    status)
      echo $LOGG
      ;;
    1)
      sed -i 's/LOGG.*$/LOGG="'$option'"/' .app/app.conf
	  echo 1
      ;;	 
    0)
	  sed -i 's/LOGG.*$/LOGG="'$option'"/' .app/app.conf
	  echo 0
	  ;;
    *)
    Message="Type '$0 -help' for more information"
    ;;
  esac	
  ;;  

### AUTOUPDATE ###
-autoupdate)
  option=$2
  case $option in
    status)
      echo $AUTO
      ;;
    1)
      sed -i 's/AUTO.*$/AUTO="'$option'"/' .app/app.conf
	  echo 1
      ;;	 
    0)
	  sed -i 's/AUTO.*$/AUTO="'$option'"/' .app/app.conf
	  echo 0
	  ;;
    *)
    Message="Type '$0 -help' for more information"
    ;;
  esac	
  ;;
  
### UPDATE ###
-update)
  ## $0 = dieses Scripts
  ## $1 = Option
  ## $2 = Filename
  ## $3 = Path to file
  
  ## Splitt Filename
  IFS='_' read -r -a array <<< "$2"
  NEWPREFIX="${array[0]}"
  NEWCCID="${array[1]}"
  NEWVERS="${array[2]}"
  tempDATI="${array[3]}"
  ## Datum und file expression trennen
  IFS='.' read -r -a array1 <<< "$tempDATI"
  NEWDATI="${array1[0]}"
  
  ## Zur Kontrolle Versionen etc. ausgeben
  echo Current Application
  echo CCID: ${CCID}
  echo Version: ${VERS}
  echo Date: ${DATI}
  echo "---"
  echo New Application
  echo CCID: ${NEWCCID}
  echo Version: ${NEWVERS}
  echo Date: ${NEWDATI}
  echo "---"
  
  ## Online / local Version vergleichen / prüfen
  ## Wenn online version höher -> Tar-Paket downloaden
  if [[ $CCID != $NEWCCID ]]; then
  	echo CCID testing failed! Wrong Filename. 
  else
  
  	if [[ $NEWVERS > $VERS ]]; then
  		if wget --spider $3/$2 > /dev/null ; then
  			echo Found new Application on Server!
  			echo Start download ...
  			echo "---"
  			cd ~/.updates
  			wget $3/$2
  			cd ~
  			echo Download done!
			echo $2
  			echo "---"
  		else
  			echo Nothing new found on Server!
  		fi
  	else
  		echo Latest Application installed! No Update available.
  		echo ""
  	fi
  
  fi
  
  if [ $AUTO = '0' ]; then
	echo Auto-Update off.
  	echo Refresh application list and install the application manually!
  else
  	echo Auto-Update on. Auto-Update and restart application!
  	echo Install application and restart, i will be back - in a minute!
  	sleep 2
  	.app/./service.sh -extract $2
  fi	
  ;;

-collect)
  ## Zeitstempel erzeugen
  DT=`date '+%Y-%m-%d-%H-%M-%S'`
  ## Zeitstempel in app.conf schreiben
  sed -i 's/DATI.*$/DATI="'${DT}'"/' .app/app.conf
  ## Die exportierte flows.json soll die default DUID haben
  sudo sed -i 's/'$UCID'/'$DUID'/g' .node-red/flows.json
  echo "Default UCID "${DUID}" gesetzt"
  sleep 1
  ## Verzeichnisse und Files zippen
  tar -czf .updates/CCID_${CCID}_${VERS}_${DT}.tar.gz .app .ucid .node-red/settings.js .node-red/flows.json .node-red/node_modules/node-red-dashboard/dist/icon* .node-red/node_modules/node-red-dashboard/dist/index.html .node-red/lib/themes/*.*
  echo "> File "CCID_${CCID}_${VERS}_${DT}.tar.gz" created!"
  sleep 1
  ## UCID zurück eintragen
  sudo sed -i 's/'$DUID'/'$UCID'/g' .node-red/flows.json
  sleep 1
  echo "UCID "${UCID}" zurückgeschrieben"
  echo ""
  ;;

-extract)
  ## Node-RED stoppen
  ## sudo systemctl stop node-red
  ## sleep 3
  ## Datei entpacken
  sudo tar -xvzf .updates/$2
  echo "File $2 extracted!"
  sleep 4
  ## Default DUID in UCID ändern
  sudo sed -i 's/'$DUID'/'$UCID'/g' .node-red/flows.json
  echo "Set UCID done. "
  sleep 1
  # Node-Red neu starten
  echo "Restart APP ..."
  sudo systemctl restart node-red
  echo ""
  echo ""
  ;;

-help)
  echo ""
  echo ""
  echo "           \|||/  "
  echo "           (o o)  "
  echo "|-------ooO-(_)-Ooo--------------------------------------------"
  echo "|"
  echo "| USAGE of service.sh"
  echo "|"
  echo "| ./service.sh -uc <UCID>"
  echo "|   >> Register the Connector at the Platform and write UCID to ucid.conf and flows.json"
  echo "|   >> Register process also bring back the CCID and the Parameter-allowed-array (to define at smart-iot.at)"
  echo "|"
  echo "| ./service.sh -cc <CCID>"
  echo "|   >> Exchange the CCID"
  echo "|"
  echo "| ./service.sh -o"
  echo "|   >> Creates a flows.json.original from current flows.json-file"
  echo "|   >> ATTENTION: only for Devs, to create a original from latests state"
  echo "|"
  echo "| ./service.sh -d"
  echo "|   >> ATTENTION: Change the UCID and CCID to factory default!"
  echo "|"
  echo "| ./service.sh -wifi <option>"
  echo "|   >> Option 'status' = resturns wifi status"
  echo "|   >> Option '1' = switches on wifi"
  echo "|   >> Option '0' = switches off wifi"
  echo "|"
  echo "| ./service.sh -logger <option>"
  echo "|   >> Option 'status' = resturns logger status"
  echo "|   >> Option '1' = switches on logger"
  echo "|   >> Option '0' = switches off logger"
  echo "|"
  echo "| ./service.sh -autoupdate <option>"
  echo "|   >> Option 'status' = resturns logger status"
  echo "|   >> Option '1' = switches on autoupdate function"
  echo "|   >> Option '0' = switches off autoupdate function"
  echo "|"
  echo "| ./service.sh -collect"
  echo "|   >> Creates a tar file from all project files"
  echo "|"
  echo "| ./service.sh -extract <filemane>"
  echo "|   >> Extracts a tar file with all project files"
  echo "|"
  echo "| ./service.sh -help"
  echo "|   >> Shows this Help"
  echo "|"
  echo "| ./service.sh -v"
  echo "|   >> Shows software version and the creation date and time"
  echo "|"
  echo "| ./service.sh -setv <xx.xx.xx>"
  echo "|   >> Set new Firmware Version and actual Timestamp"
  echo "|"
  echo "|-------------------------------------------------------------"
  echo ""
  echo ""
  echo ""
  ;;
*)
  ## $0 is my own file name
  echo "Type '$0 -help' for more information"
  ;;
esac
