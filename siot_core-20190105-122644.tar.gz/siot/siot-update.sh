#!/bin/bash
# After unpacking siot_core-xyz.tar run this script

case $1 in

-register)
uuid=$2
  if [[ ${uuid//-/} =~ ^[[:xdigit:]]{32}$ ]]; then
      echo "UUID Format correct"
	
	  ## lesen der aktuellen ID
      currentID=$(<.siot/.siot_ucid)
      echo "Current UCID: "$currentID
	  echo ""
      sleep 1

      #$1 wird von eingabe übernommen
      echo "New UCID: "$2
	  echo ""
      echo $2 > .siot/.siot_ucid

      # Aktuelle UCID gegen neue UCID tauschen
      echo "Schreibe neue UCID: "$2
	  echo ""
      sed -i -- 's/'$currentID'/'$2'/g' .node-red/flows.json
      sleep 2

      # Node-Red neu starten
      echo "All done, restart APP ..."
      systemctl restart node-red
  else
      echo "UUID not allowed"
  fi
  Message="Register connenctor complete"
  ;;

-original)
  ## Dieses Script erzeugt eine original flow.json mit default MQTT-ID (UCID)
  ## lesen der aktuellen UCID
  currentID=$(<.siot/.siot_ucid)
  defaultID="DEFAULT_UCID"
  echo "> Current UCID: "$currentID
  sleep 1
  
  ## Copy the current flows.json-file
  echo ">> Copy flows.json 2 flows.json.original" 
  sudo cp .node-red/flows.json .siot/flows.json.original
  sleep 1
  echo ">>> File 'flows.json.original' created."
  sleep 1
  
  ## Change the UCID to default
  echo ">>>> Change '$currentID' to 'DEFAULT_UCID' in File flows.json.original"
  sudo sed -i -- 's/'$currentID'/DEFAULT_UCID/g' .siot/flows.json.original
  sleep 1
  
  Message="Function done!"
  ;;

-factory)
  currentID=$(<.siot/.siot_ucid)
  defaultID="DEFAULT_UCID"
  echo "> Current UCID: "$currentID
  sleep 1
  
  # Copy Original to working flows 
  echo ">> Copy flows.json.original to flows.json" 
  sudo cp .siot/flows.json.original .node-red/flows.json
  echo $defaultID > .siot/.siot_ucid
  echo "" > .siot/.siot_ccid
  sleep 2
  # Restart Node-Red
  echo ">>> Restart APP, this needs a few seconds, don't worry!"
  sudo systemctl restart node-red
  ;;
### WIFI ###
-wifi)
  option=$2
  currentWIFISTATUS=$(<.siot_wifi_status)
  #defaultSTATUS="ON"
  #echo "> Current Wifi status: "$currentSTATUS
  #sleep 1
  case $option in
    status)
      echo $currentWIFISTATUS
      ;;
    1)
      nmcli r wifi on
	  echo $option > .siot/.siot_wifi_status
      ;;	 
    0)
      nmcli r wifi off
	  echo $option > .siot/.siot_wifi_status
	  ;;
    *)
    Message="Type '$0 -help' for more information"
    ;;
  esac	
  ;;
-mktar)
  tar -czf siot_core-`date +%Y%m%d-%H%M%S`.tar.gz .siot .node-red/settings.js .node-red/flows.json
  echo "> File created!"
  ;;
-help)
  echo ""
  echo ""
  echo "           \|||/  "
  echo "           (o o)  "
  echo "|-------ooO-(_)-Ooo--------------------------------------------"
  echo "|"
  echo "| USAGE of siot-config.sh"
  echo "|"
  echo "| ./siot-config.sh -register <UCID>"
  echo "|   >> Register the Connector and write UCID to flows.json-file"
  echo "|"
  echo "| ./siot-config.sh -original"
  echo "|   >> Creates a flows.json.original from current flows.json-file"
  echo "|   >> For Developers, to create a original from latests state"
  echo "|"
  echo "| ./siot-config.sh -factory"
  echo "|   >> ATTENTION: Reset the Connector to factory default!"
  echo "|   >> Overwrite the flows.json-file!"
  echo "|"
  echo "| ./siot-config.sh -wifi"
  echo "|   >> Register the Connector and write UCID to flows.json-file"
  echo "|"
  echo "| ./siot-config.sh -mktar"
  echo "|   >> Creates a tar from all siot files"
  echo "|"
  echo "| ./siot-config.sh -help"
  echo "|   >> Shows this Help"
  echo "|"
  echo "|-------------------------------------------------------------"
  echo ""
  echo ""
  echo ""
  ;;
*)
  ## $0 is my own file name
  Message="Type '$0 -help' for more information"
  ;;
esac

echo $Message