#!/bin/bash

## INFO ##
## $0 = Filename dieses Scripts
## $1 = Option 1 -> case
## $2 = Option 2 -> Parameter für den case
## Beispiel für Verwendung der eingelesenen Variablen: echo $UCID
## Beispiel für das Ändern der Variable im File: sed -i 's/UCID.*$/UCID="'$2'"/' .siot/siot.conf
## ACHTUNG, es werden immer ALLE Zeichenfolgen ersetzt, Variablenname müssen also eindeutig sein, auch in Teilen

## Alle Variablen einlesen
## Pfad ist relativ zum Arbeitsverzeichnis
source .siot/siot.conf

case $1 in

-uc)
uuid=$2
  if [[ ${uuid//-/} =~ ^[[:xdigit:]]{32}$ ]]; then
      echo "UUID Format correct!"
	
	  ## lesen der aktuellen ID
      echo "Current UCID: "$UCID
      sleep 1

      #$1 wird von eingabe übernommen
      echo "--> New UCID: "$2
	  
      # Ersetze alte durch neue UCID in File .variables
	  sed -i 's/UCID.*$/UCID="'$2'"/' .siot/siot.conf

      # Ersetze alte durch neue UCID in File .node-red/flows.json
      echo "Set new UCID: "$2
	  echo ""
      sed -i -- 's/'$UCID'/'$2'/g' .node-red/flows.json
      sleep 1

      # Node-Red neu starten
      echo "All done, restart APP ..."
      systemctl restart node-red
  else
      echo "UCID not allowed"
  fi
  ## Message="Register connenctor complete"
  ;;

-cc)
uuid=$2
  if [[ ${uuid//-/} =~ ^[[:xdigit:]]{32}$ ]]; then
      echo "UUID Format correct!"
	
	  ## lesen der aktuellen ID
      echo "Current CCID: "$CCID
      sleep 1

      #$1 wird von eingabe übernommen
      echo "--> New CCID: "$2
	  
      # Ersetze alte durch neue UCID in File .variables
	  sed -i 's/CCID.*$/CCID="'$2'"/' .siot/siot.conf
	  echo "Done."
  else
      echo "CCID not allowed"
  fi
  ;;

-o)
  ## Dieses Script erzeugt eine original flow.json mit default MQTT-ID (UCID)
  echo "> Current UCID: "$UCID
  sleep 1
  
  ## Copy the current flows.json-file
  echo ">> Copy current flows.json to flows.json.original" 
  sudo cp .node-red/flows.json .siot/flows.json.original
  sleep 1
  echo ">>> File 'flows.json.original' created."
  sleep 1
  
  ## Change the UCID to default
  echo ">>>> Change '$UCID' to '$DUID' in File flows.json.original"
  sudo sed -i -- 's/'$UCID'/'$DUID'/g' .siot/flows.json.original
  sleep 1
  
  echo "Done."
  ;;

### Delete UCID ###  
-d)
  echo "> Current UCID: "$UCID
  sleep 1
  
  ## Change the UCID to default
  echo ">> Change UCID to '$DUID' in flows.json"
  sudo sed -i -- 's/'$UCID'/'$DUID'/g' .node-red/flows.json
  sleep 1
  
  ## Ersetze alte durch neue UCID in File siot.conf
  echo ">>> Change UCID ans CCID to Default in File siot.conf"
  sed -i 's/UCID.*$/UCID="'$DUID'"/' .siot/siot.conf
  sleep 1
  sed -i 's/CCID.*$/CCID="'$DUID'"/' .siot/siot.conf
  sleep 1

  # Restart Node-Red
  echo ">>>> Restart APP, this needs a few seconds, don't worry!"
  sudo systemctl restart node-red
  ;;
  
### Version ###  
-v)
  echo $VERS
  ;;

### WIFI ###
-wifi)
  option=$2
  case $option in
    status)
      echo $WIFI
      ;;
    1)
      nmcli r wifi on
	  sed -i 's/WIFI.*$/WIFI="'$option'"/' .siot/siot.conf
      ;;	 
    0)
      nmcli r wifi off
	  sed -i 's/WIFI.*$/WIFI="'$option'"/' .siot/siot.conf
	  ;;
    *)
    Message="Type '$0 -help' for more information"
    ;;
  esac	
  ;;
-mktar)
  tar -czf siot_core-`date +%Y%m%d-%H%M%S`.tar.gz .siot .node-red/settings.js .node-red/flows.json .node-red/node_modules/node-red-dashboard/dist/icon*
  echo "> File siot_core-"`date +%Y%m%d-%H%M%S`".tar.gz created!"
  ;;
-help)
  echo ""
  echo ""
  echo "           \|||/  "
  echo "           (o o)  "
  echo "|-------ooO-(_)-Ooo--------------------------------------------"
  echo "|"
  echo "| USAGE of siot-config.sh"
  echo "|"
  echo "| ./siot-config.sh -uc <UCID>"
  echo "|   >> Register the Connector at the Platform and write UCID to siot.conf and flows.json"
  echo "|   >> Register process also get back CCID and the Parameter-allowed-array (to define at smart-iot.at)"
  echo "|"
  echo "| ./siot-config.sh -cc <CCID>"
  echo "|   >> Exchange the CCID in siot.conf"
  echo "|"
  echo "| ./siot-config.sh -o"
  echo "|   >> Creates a flows.json.original from current flows.json-file"
  echo "|   >> ATTENTION: only for Devs, to create a original from latests state"
  echo "|"
  echo "| ./siot-config.sh -d"
  echo "|   >> ATTENTION: Change the UCID to factory default!"
  echo "|"
  echo "| ./siot-config.sh -wifi <option>"
  echo "|   >> Option 'status' = resturns wifi status"
  echo "|   >> Option '1' = switches on wifi"
  echo "|   >> Option '0' = switches off wifi"
  echo "|"
  echo "| ./siot-config.sh -mktar"
  echo "|   >> Creates a tar from all siot files"
  echo "|"
  echo "| ./siot-config.sh -help"
  echo "|   >> Shows this Help"
  echo "|"
  echo "| ./siot-config.sh -v"
  echo "|   >> Shows Software-Version"
  echo "|"
  echo "|-------------------------------------------------------------"
  echo ""
  echo ""
  echo ""
  ;;
*)
  ## $0 is my own file name
  echo "Type '$0 -help' for more information"
  ;;
esac
